<?php

namespace EduCBTPro\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * PHASE 1 — migration registry.
 *
 * MigrationManager already existed but nothing was ever registered with it;
 * activation called create_tables() directly, so there was no version history and
 * no way to run a data migration exactly once. This class supplies the ordered map.
 *
 * Schema changes and data backfills are deliberately separate versions. A schema
 * step is fast and safe to rerun; a backfill over 500 students and thousands of
 * questions is neither, and must be resumable on its own.
 */
class Migrations {

    public static function register( MigrationManager $manager ): void {

        // 1.0.0 — the v1 tables, as they shipped. Retained so an existing install
        // records a truthful starting version rather than jumping straight to 2.x.
        $manager->register( '1.0.0', static function (): void {
            ( new TenantContext() )->create_tables();
        } );

        // 2.0.0 — the relational v2 tables, created alongside v1. Non-destructive.
        $manager->register( '2.0.0', static function (): void {
            Schema::install();
        } );

        // 2.0.1 — seed academic defaults, then migrate v1 string data into v2 rows.
        $manager->register( '2.0.1', static function ( $wpdb ): void {
            $schools = (array) $wpdb->get_col( 'SELECT id FROM ' . $wpdb->prefix . 'educbt_schools' );

            $backfill = new Backfill();
            $reports  = [];

            foreach ( $schools as $school_id ) {
                $reports[ absint( $school_id ) ] = $backfill->run( absint( $school_id ) );
            }

            // Kept so an administrator can inspect what could not be mapped rather
            // than discovering it mid-term.
            update_option( 'educbt_backfill_report', $reports, false );
        } );
    }

    /**
     * Run every pending migration. Safe to call on each activation.
     *
     * @return array<int,string> versions applied
     */
    public static function run(): array {
        $manager = new MigrationManager();
        self::register( $manager );

        return $manager->run();
    }

    /**
     * The unresolved rows from the last backfill, for the admin health screen.
     *
     * @return array<int,array<string,mixed>>
     */
    public static function unresolved(): array {
        $reports = get_option( 'educbt_backfill_report', [] );
        if ( ! is_array( $reports ) ) {
            return [];
        }

        $rows = [];

        foreach ( $reports as $report ) {
            foreach ( (array) ( $report['unresolved'] ?? [] ) as $item ) {
                $rows[] = $item;
            }
        }

        return $rows;
    }
}

<?php

namespace EduCBTPro\Core\Repository;

use EduCBTPro\Core\Models\School;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SchoolRepository {
    public function get_all_schools(): array {
        global $wpdb;
        $table = $wpdb->prefix . 'educbt_schools';
        return $wpdb->get_results( "SELECT * FROM {$table}", ARRAY_A ) ?: [];
    }

    public function get_school_by_id( int $id ): ?School {
        global $wpdb;
        $table = $wpdb->prefix . 'educbt_schools';
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ), ARRAY_A );

        if ( ! $row ) {
            return null;
        }

        $school = new School();
        foreach ( $row as $key => $value ) {
            if ( property_exists( $school, $key ) ) {
                // Coalesce null to empty string — model properties are typed string
                $school->{$key} = $value ?? '';
            }
        }

        return $school;
    }

    public function create_school( array $data ): int {
        global $wpdb;
        $table = $wpdb->prefix . 'educbt_schools';

        $wpdb->insert(
            $table,
            [
                'school_name'      => sanitize_text_field( $data['school_name'] ?? '' ),
                'school_code'      => sanitize_text_field( $data['school_code'] ?? '' ),
                'logo'             => sanitize_text_field( $data['logo'] ?? '' ),
                'address'          => sanitize_textarea_field( $data['address'] ?? '' ),
                'phone'            => sanitize_text_field( $data['phone'] ?? '' ),
                'email'            => sanitize_email( $data['email'] ?? '' ),
                'website'          => esc_url_raw( $data['website'] ?? '' ),
                'principal_name'   => sanitize_text_field( $data['principal_name'] ?? '' ),
                'academic_settings'=> wp_json_encode( $data['academic_settings'] ?? [] ),
                'report_settings'  => wp_json_encode( $data['report_settings'] ?? [] ),
            ],
            [ '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' ]
        );

        return (int) $wpdb->insert_id;
    }

    public function update_academic_settings( int $school_id, array $academic_settings ): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'educbt_schools';

        $updated = $wpdb->update(
            $table,
            [
                'academic_settings' => wp_json_encode( $academic_settings ),
            ],
            [
                'id' => $school_id,
            ],
            [ '%s' ],
            [ '%d' ]
        );

        return $updated !== false;
    }
}

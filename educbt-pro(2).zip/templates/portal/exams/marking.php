<?php
/**
 * Mark written answers.
 *
 * Grouped by question rather than by student, because that is how examiners work:
 * marking every answer to question 1 before moving on keeps the standard consistent
 * across a class.
 *
 * @var array<string,mixed> $educbt
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$school_id = (int) $educbt['school_id'];
$paper_id  = (int) $educbt['id'];
$flash     = \EduCBTPro\Frontend\PortalActions::flash();

$theory = new \EduCBTPro\Services\TheoryService();
$actor  = $educbt['scope']->actor();

$pending = $theory->papers_awaiting_marking(
    $school_id,
    $educbt['scope']->is_school_wide() ? 0 : (int) $actor['id']
);

$queue    = $paper_id > 0 ? $theory->marking_queue( $school_id, $paper_id ) : [];
$progress = $paper_id > 0 ? $theory->marking_progress( $school_id, $paper_id ) : null;

$educbt_title = 'Mark Written Answers';

$educbt_body = static function () use ( $flash, $pending, $queue, $progress, $paper_id ): void {
    require EDUCBT_PRO_PATH . 'templates/portal/partials/flash.php';
    ?>
    <section class="educbt-card">
        <h2>Papers awaiting marking</h2>
        <?php if ( empty( $pending ) ) : ?>
            <p class="educbt-muted">Nothing outstanding.</p>
        <?php else : ?>
            <ul class="educbt-list">
            <?php foreach ( $pending as $p ) : ?>
                <li>
                    <span><strong><?php echo esc_html( (string) $p['subject_name'] ); ?></strong> — <?php echo esc_html( (string) $p['class_name'] ); ?></span>
                    <span class="educbt-pill educbt-pill--draft"><?php echo esc_html( (string) $p['outstanding'] ); ?> to mark</span>
                    <a class="educbt-btn <?php echo (int) $p['id'] === $paper_id ? 'educbt-btn--primary' : ''; ?>"
                       href="<?php echo esc_url( home_url( '/portal/exams/marking/' . (int) $p['id'] ) ); ?>">Mark</a>
                </li>
            <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </section>

    <?php if ( $progress && $progress['total'] > 0 ) : ?>
        <section class="educbt-card">
            <p class="educbt-muted" style="margin:0">
                <?php echo esc_html( sprintf( '%d of %d answers marked.', (int) $progress['marked'], (int) $progress['total'] ) ); ?>
                <?php if ( (int) $progress['outstanding'] > 0 ) : ?>
                    <strong>Results must not be compiled until this reaches zero</strong> — unmarked
                    answers would count as nought and fail the class silently.
                <?php endif; ?>
            </p>
        </section>
    <?php endif; ?>

    <?php foreach ( $queue as $group ) : ?>
        <section class="educbt-card">
            <h2>Question <span class="educbt-muted">(<?php echo esc_html( (string) $group['marked'] ); ?>/<?php echo esc_html( (string) $group['total'] ); ?> marked, max <?php echo esc_html( (string) (float) $group['max_marks'] ); ?>)</span></h2>
            <div style="background:var(--edu-bg);border-radius:9px;padding:12px;margin-bottom:14px">
                <?php echo wp_kses_post( wpautop( (string) $group['question_text'] ) ); ?>
            </div>

            <?php if ( trim( (string) $group['marking_guide'] ) !== '' ) : ?>
                <details style="margin-bottom:14px">
                    <summary style="cursor:pointer;font-weight:600;font-size:14px">Marking guide</summary>
                    <div class="educbt-muted" style="margin-top:8px"><?php echo wp_kses_post( wpautop( (string) $group['marking_guide'] ) ); ?></div>
                </details>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="educbt-form">
                <input type="hidden" name="action" value="educbt_mark_theory">
                <input type="hidden" name="paper_id" value="<?php echo esc_attr( (string) $paper_id ); ?>">
                <input type="hidden" name="max_marks" value="<?php echo esc_attr( (string) (float) $group['max_marks'] ); ?>">
                <?php wp_nonce_field( 'educbt_mark_theory' ); ?>

                <?php foreach ( $group['answers'] as $answer ) : ?>
                    <div style="border:1px solid var(--edu-line);border-radius:9px;padding:13px;margin-bottom:11px">
                        <p style="margin:0 0 8px;font-size:13.5px">
                            <strong><?php echo esc_html( (string) $answer['student_name'] ); ?></strong>
                            <span class="educbt-muted"><?php echo esc_html( (string) $answer['admission_number'] ); ?></span>
                        </p>

                        <?php if ( trim( (string) $answer['answer_text'] ) === '' ) : ?>
                            <p class="educbt-muted"><em>No answer written.</em></p>
                        <?php else : ?>
                            <div style="white-space:pre-wrap;font-size:14.5px"><?php echo esc_html( (string) $answer['answer_text'] ); ?></div>
                        <?php endif; ?>

                        <div style="display:flex;align-items:center;gap:10px;margin-top:10px">
                            <label style="margin:0">Mark</label>
                            <input type="number" step="0.5" min="0" max="<?php echo esc_attr( (string) (float) $group['max_marks'] ); ?>"
                                   name="marks[<?php echo esc_attr( (string) $answer['answer_id'] ); ?>]"
                                   value="<?php echo $answer['marked'] ? esc_attr( (string) (float) $answer['marks_awarded'] ) : ''; ?>"
                                   style="width:90px;padding:7px">
                            <span class="educbt-muted">of <?php echo esc_html( (string) (float) $group['max_marks'] ); ?></span>
                            <?php if ( $answer['marked'] ) : ?>
                                <span class="educbt-pill educbt-pill--approved">marked</span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>

                <p class="educbt-muted">Leave a box empty to come back to it — that is different from a zero.</p>
                <button type="submit" class="educbt-btn educbt-btn--primary">Save marks</button>
            </form>
        </section>
    <?php endforeach; ?>

    <?php if ( $paper_id > 0 && empty( $queue ) ) : ?>
        <div class="educbt-card"><p class="educbt-muted">This paper has no written answers to mark.</p></div>
    <?php endif; ?>
    <?php
};

require EDUCBT_PRO_PATH . 'templates/portal/shell.php';

<?php
/**
 * The question bank.
 *
 * Restructured around how the work actually goes. A teacher sits down with a list of
 * questions and enters them one after another, so:
 *
 *  - The CONTEXT — subject, class, kind — is set once at the top and stays put.
 *  - Saving does not reload the page, so the context is never thrown away and the
 *    counter can advance in place.
 *  - A passage is attached BEFORE the question, because that is the order the
 *    thinking goes: here is the passage, now here are its questions.
 *  - Objective and written questions are listed separately. Mixed together, a
 *    teacher could not tell at a glance whether they had enough of each.
 *
 * @var array<string,mixed> $educbt
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

global $wpdb;

$school_id = (int) $educbt['school_id'];
$flash     = \EduCBTPro\Frontend\PortalActions::flash();
$exam_prep_open = ( new \EduCBTPro\Services\SchoolService() )->is_exam_prep_enabled( $school_id );
$actor     = $educbt['scope']->actor();

$subjects_table = \EduCBTPro\Core\Schema::table( 'subjects_v2' );
$questions      = $wpdb->prefix . 'educbt_questions';
$options_table  = \EduCBTPro\Core\Schema::table( 'question_options' );
$assign         = \EduCBTPro\Core\Schema::table( 'staff_assignments' );

$is_reviewer = $educbt['scope']->is_school_wide();

// A teacher writes for the subjects they teach, not for all 42.
if ( $is_reviewer ) {
    $subjects = (array) $wpdb->get_results(
        $wpdb->prepare( "SELECT id, name FROM {$subjects_table} WHERE school_id = %d AND status = 'active' ORDER BY name ASC", $school_id ),
        ARRAY_A
    );
} else {
    $subjects = (array) $wpdb->get_results(
        $wpdb->prepare(
            "SELECT DISTINCT s.id, s.name FROM {$assign} a
             INNER JOIN {$subjects_table} s ON s.id = a.subject_id
             WHERE a.school_id = %d AND a.staff_id = %d AND a.status = 'active' AND s.status = 'active'
             ORDER BY s.name ASC",
            $school_id,
            (int) $actor['id']
        ),
        ARRAY_A
    );
}

$subject_ids = array_map( static fn( array $s ): int => (int) $s['id'], $subjects );

$levels = (array) $wpdb->get_results(
    $wpdb->prepare(
        'SELECT name, code FROM ' . \EduCBTPro\Core\Schema::table( 'class_levels' ) . ' WHERE school_id = %d ORDER BY level_order ASC',
        $school_id
    ),
    ARRAY_A
);

$passages = (array) $wpdb->get_results(
    $wpdb->prepare(
        'SELECT id, title FROM ' . \EduCBTPro\Core\Schema::table( 'passages' ) . " WHERE school_id = %d AND status = 'active' ORDER BY id DESC LIMIT 50",
        $school_id
    ),
    ARRAY_A
);

$counts          = [];
$bank_objective  = [];
$bank_theory     = [];
$filter_subject  = (int) ( $_GET['subject'] ?? 0 );

if ( ! empty( $subject_ids ) ) {
    $holder = implode( ',', array_fill( 0, count( $subject_ids ), '%d' ) );

    foreach ( (array) $wpdb->get_results(
        $wpdb->prepare(
            "SELECT subject_id, class_level, COUNT(*) AS n FROM {$questions}
             WHERE school_id = %d AND status = 'active' AND subject_id IN ({$holder})
             GROUP BY subject_id, class_level",
            array_merge( [ $school_id ], $subject_ids )
        ),
        ARRAY_A
    ) as $row ) {
        $counts[ (int) $row['subject_id'] . '|' . (string) $row['class_level'] ] = (int) $row['n'];
    }

    $ids       = $filter_subject > 0 && in_array( $filter_subject, $subject_ids, true ) ? [ $filter_subject ] : $subject_ids;
    $id_holder = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

    $rows = (array) $wpdb->get_results(
        $wpdb->prepare(
            "SELECT q.id, q.question_text, q.question_type, q.marks, q.class_level, q.approval_status,
                    q.review_note, s.name AS subject_name,
                    (SELECT COUNT(*) FROM {$options_table} o WHERE o.question_id = q.id AND o.is_correct = 1) AS correct_count
             FROM {$questions} q
             INNER JOIN {$subjects_table} s ON s.id = q.subject_id
             WHERE q.school_id = %d AND q.status = 'active' AND q.subject_id IN ({$id_holder})
             ORDER BY q.id DESC LIMIT 300",
            array_merge( [ $school_id ], $ids )
        ),
        ARRAY_A
    );

    foreach ( $rows as $row ) {
        $row['options'] = (array) $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, option_key, option_text, is_correct FROM {$options_table} WHERE question_id = %d ORDER BY sort_order ASC",
                (int) $row['id']
            ),
            ARRAY_A
        );

        if ( (string) $row['question_type'] === 'theory' ) {
            $bank_theory[] = $row;
        } else {
            $bank_objective[] = $row;
        }
    }
}

$approvals      = new \EduCBTPro\Services\QuestionApprovalService();
$quotas         = $approvals->quotas( $school_id );
$my_submissions = $is_reviewer ? [] : $approvals->submissions( $school_id, (int) $actor['id'] );

wp_enqueue_script(
    'educbt-questions',
    EDUCBT_PRO_URL . 'assets/js/educbt-questions.js',
    [],
    (string) filemtime( EDUCBT_PRO_DIR . 'assets/js/educbt-questions.js' ),
    true
);

wp_localize_script(
    'educbt-questions',
    'EduCBTQuestions',
    [
        'root'   => esc_url_raw( rest_url( 'educbt/v1/' ) ),
        'nonce'  => wp_create_nonce( 'wp_rest' ),
        'counts' => $counts,
    ]
);

$educbt_title = 'Question Bank';

$educbt_body = static function () use (
    $flash, $subjects, $levels, $passages, $bank_objective, $bank_theory,
    $filter_subject, $is_reviewer, $my_submissions, $quotas, $exam_prep_open
): void {
    require EDUCBT_PRO_PATH . 'templates/portal/partials/flash.php';

    if ( ! $exam_prep_open && ! $is_reviewer ) {
        echo '<div class="educbt-card"><p class="educbt-note educbt-note--warn">Exam preparation is currently closed. You cannot submit new questions until it is opened.</p></div>';
        return;
    }

    if ( empty( $subjects ) ) {
        echo '<div class="educbt-card"><p class="educbt-note educbt-note--warn">You have not been assigned a subject yet, so there is nothing to write questions for.</p></div>';
        return;
    }

    if ( ! empty( $my_submissions ) ) : ?>
        <section class="educbt-card">
            <h2>My submission status</h2>
            <table class="educbt-table">
                <thead><tr><th>Subject</th><th>Objective</th><th>Written</th><th>Review</th></tr></thead>
                <tbody>
                <?php foreach ( $my_submissions as $sub ) : ?>
                    <tr>
                        <td><?php echo esc_html( (string) $sub['subject_name'] ); ?></td>
                        <td>
                            <strong><?php echo esc_html( (string) $sub['objective'] ); ?></strong>
                            <?php if ( $sub['short_objective'] > 0 ) : ?>
                                <span class="educbt-pill educbt-pill--draft"><?php echo esc_html( (string) $sub['short_objective'] ); ?> below the minimum of <?php echo esc_html( (string) $quotas['objective'] ); ?></span>
                            <?php else : ?>
                                <span class="educbt-muted">minimum met</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <strong><?php echo esc_html( (string) $sub['theory'] ); ?></strong>
                            <?php if ( $sub['short_theory'] > 0 ) : ?>
                                <span class="educbt-pill educbt-pill--draft"><?php echo esc_html( (string) $sub['short_theory'] ); ?> below the minimum of <?php echo esc_html( (string) $quotas['theory'] ); ?></span>
                            <?php else : ?>
                                <span class="educbt-muted">minimum met</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ( (int) $sub['revision'] > 0 ) : ?>
                                <span class="educbt-pill educbt-pill--draft"><?php echo esc_html( (string) $sub['revision'] ); ?> sent back</span>
                            <?php elseif ( (int) $sub['pending'] > 0 ) : ?>
                                <span class="educbt-pill educbt-pill--submitted"><?php echo esc_html( (string) $sub['pending'] ); ?> awaiting approval</span>
                            <?php else : ?>
                                <span class="educbt-pill educbt-pill--approved">all approved</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </section>
    <?php endif; ?>

    <section class="educbt-card">
        <h2>1 &nbsp;What are you writing for?</h2>
        <p class="educbt-muted" style="margin-top:-6px">Set once — it stays as you work through your questions.</p>

        <div class="educbt-grid">
            <div>
                <label for="subject_id">Subject *</label>
                <select id="subject_id" required>
                    <option value="">Choose</option>
                    <?php foreach ( $subjects as $s ) : ?>
                        <option value="<?php echo esc_attr( (string) $s['id'] ); ?>"><?php echo esc_html( (string) $s['name'] ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label for="class_level">Class *</label>
                <select id="class_level" required>
                    <option value="">Choose</option>
                    <?php foreach ( $levels as $lvl ) : ?>
                        <option value="<?php echo esc_attr( (string) $lvl['code'] ); ?>"><?php echo esc_html( (string) $lvl['name'] ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label for="qtype">Kind of question</label>
                <select id="qtype">
                    <option value="single_choice">Objective — student picks an option</option>
                    <option value="theory">Written — student writes an answer</option>
                </select>
            </div>
            <div>
                <label for="suggested_duration">Suggested exam duration (minutes)</label>
                <input id="suggested_duration" type="number" min="5" max="300" value="60" placeholder="60">
                <p class="educbt-muted" style="margin-top:4px;font-size:12.5px">How long should this exam run? The exam officer can adjust this later.</p>
            </div>
            <div id="q-marks-field" hidden>
                <label for="marks">Marks</label>
                <input id="marks" type="number" step="0.5" min="0.5" value="1">
            </div>
        </div>
    </section>

    <section class="educbt-card">
        <h2>2 &nbsp;Passage <span class="educbt-muted">(optional)</span></h2>
        <p class="educbt-muted" style="margin-top:-6px">
            For comprehension or summary. Attach one and every question you write next
            hangs off it — they stay together and in order when the paper is shuffled.
        </p>

        <div class="educbt-grid">
            <div>
                <label for="passage_id">Use an existing passage</label>
                <select id="passage_id">
                    <option value="">None</option>
                    <?php foreach ( $passages as $p ) : ?>
                        <option value="<?php echo esc_attr( (string) $p['id'] ); ?>"><?php echo esc_html( (string) $p['title'] ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <details style="margin-top:12px">
            <summary style="cursor:pointer;font-weight:600;font-size:14px">Add a new passage</summary>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="educbt-form" style="margin-top:10px">
                <input type="hidden" name="action" value="educbt_save_passage">
                <?php wp_nonce_field( 'educbt_save_passage' ); ?>
                <label for="passage_title">Title</label>
                <input id="passage_title" name="passage_title" type="text" placeholder="Read the following passage">
                <label for="passage_body" style="margin-top:8px">Passage text</label>
                <textarea id="passage_body" name="passage_body" rows="6"></textarea>
                <button type="submit" class="educbt-btn" style="margin-top:10px">Save passage</button>
                <span class="educbt-muted" style="margin-left:8px">Saving a passage reloads the page once, then it is selectable above.</span>
            </form>
        </details>
    </section>

    <section class="educbt-card">
        <h2>3 &nbsp;<span id="question-number">Question</span></h2>

        <label for="question_text">The question *</label>
        <textarea id="question_text" rows="3" placeholder="Type the question…"></textarea>

        <div id="q-image-field" style="margin-top:12px">
            <label>Image <span class="educbt-muted">(optional)</span></label>
            <?php echo \EduCBTPro\Frontend\MediaField::render( 'question_image_unused', '', 'Choose image', 'wide' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
            <input type="hidden" id="question_image">
        </div>

        <div id="q-objective" style="margin-top:14px">
            <p class="educbt-muted" style="margin-bottom:8px">Options — fill at least two and choose the correct one.</p>
            <?php foreach ( [ 'A', 'B', 'C', 'D' ] as $key ) : ?>
                <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
                    <label style="margin:0;display:flex;align-items:center;gap:6px;min-width:60px">
                        <input type="radio" name="correct" value="<?php echo esc_attr( $key ); ?>" style="width:auto" <?php checked( $key, 'A' ); ?>>
                        <strong><?php echo esc_html( $key ); ?></strong>
                    </label>
                    <input id="option_<?php echo esc_attr( $key ); ?>" type="text" placeholder="Option <?php echo esc_attr( $key ); ?>">
                </div>
            <?php endforeach; ?>
        </div>

        <div id="q-theory" hidden style="margin-top:14px">
            <p class="educbt-note">
                A written question is marked by a teacher after the exam. Results cannot be
                compiled until every answer has been marked.
            </p>
            <label for="marking_guide">Marking guide <span class="educbt-muted">(seen only by the marker)</span></label>
            <textarea id="marking_guide" rows="4" placeholder="2 marks for identifying the figure of speech, 3 for explaining its effect…"></textarea>
        </div>

        <div style="display:flex;align-items:center;gap:14px;margin-top:16px;flex-wrap:wrap">
            <button type="button" id="q-save" class="educbt-btn educbt-btn--primary">Save and write the next</button>
            <span id="q-status" class="q-status"></span>
        </div>
        <p class="educbt-muted" style="margin-top:8px">
            Saved questions are submitted for approval automatically. Ctrl+Enter saves.
        </p>
    </section>

    <section class="educbt-card" id="q-tally-wrap" hidden>
        <h2>Written in this sitting</h2>
        <ul class="q-tally" id="q-tally"></ul>
    </section>

    <section class="educbt-card">
        <h2>Add many at once</h2>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="educbt-form" enctype="multipart/form-data">
            <input type="hidden" name="action" value="educbt_import_questions">
            <?php wp_nonce_field( 'educbt_import_questions' ); ?>

            <div class="educbt-grid">
                <div>
                    <label for="bulk_subject">Subject *</label>
                    <select id="bulk_subject" name="subject_id" required>
                        <option value="">Choose</option>
                        <?php foreach ( $subjects as $s ) : ?>
                            <option value="<?php echo esc_attr( (string) $s['id'] ); ?>"><?php echo esc_html( (string) $s['name'] ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label for="bulk_class">Class *</label>
                    <select id="bulk_class" name="class_level" required>
                        <option value="">Choose</option>
                        <?php foreach ( $levels as $lvl ) : ?>
                            <option value="<?php echo esc_attr( (string) $lvl['code'] ); ?>"><?php echo esc_html( (string) $lvl['name'] ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label for="mode">How are you adding them?</label>
                    <select id="mode" name="mode" onchange="educbtImportMode(this.value)">
                        <option value="paste">Paste the text</option>
                        <option value="csv">Upload a CSV file</option>
                    </select>
                </div>
            </div>

            <div id="import-paste" style="margin-top:12px">
                <label for="bulk">Questions</label>
                <textarea id="bulk" name="bulk" rows="9" placeholder="1. What is the SI unit of force?&#10;A. Newton&#10;B. Joule&#10;C. Watt&#10;D. Pascal&#10;Answer: A"></textarea>
                <p class="educbt-muted" style="margin-top:6px">
                    Numbering in what you paste is ignored — questions continue from what you
                    already have. Options may be <code>A.</code> or <code>(a)</code>, and the
                    answer may be an <code>Answer:</code> line or an asterisk on the right option.
                </p>
            </div>

            <div id="import-csv" style="margin-top:12px" hidden>
                <label for="csv_file">CSV file</label>
                <input id="csv_file" name="csv_file" type="file" accept=".csv,text/csv">
                <p style="margin-top:8px">
                    <a class="educbt-btn" href="<?php echo esc_url( admin_url( 'admin-post.php?action=educbt_question_template&_wpnonce=' . wp_create_nonce( 'educbt_question_template' ) ) ); ?>">Download the template</a>
                </p>
            </div>

            <button type="submit" class="educbt-btn educbt-btn--primary" style="margin-top:14px">Import</button>
        </form>

        <script>
        function educbtImportMode(mode) {
            var isCsv = mode === 'csv';
            document.getElementById('import-paste').hidden = isCsv;
            document.getElementById('import-csv').hidden = !isCsv;
            document.getElementById('bulk').required = !isCsv;
            document.getElementById('csv_file').required = isCsv;
        }
        </script>
    </section>

    <?php
    // The bank, objective and written kept apart.
    $render_bank = static function ( array $rows, string $heading, bool $objective ) use ( $is_reviewer ): void {
        ?>
        <section class="educbt-card">
            <h2><?php echo esc_html( $heading ); ?> <span class="educbt-muted">(<?php echo esc_html( (string) count( $rows ) ); ?>)</span></h2>

            <?php if ( empty( $rows ) ) : ?>
                <p class="educbt-muted">None yet.</p>
                <?php return; ?>
            <?php endif; ?>

            <?php foreach ( $rows as $i => $q ) :
                $qid = (int) $q['id']; ?>
                <div class="q-item">
                    <div class="q-item__head">
                        <span class="educbt-muted"><?php echo esc_html( (string) ( $i + 1 ) ); ?>.</span>
                        <span class="educbt-pill educbt-pill--<?php echo esc_attr( (string) ( $q['approval_status'] ?: 'pending' ) ); ?>">
                            <?php echo esc_html( (string) ( $q['approval_status'] === 'revision' ? 'sent back' : ( $q['approval_status'] ?: 'pending' ) ) ); ?>
                        </span>
                        <span class="educbt-muted">
                            <?php echo esc_html( (string) $q['subject_name'] ); ?>
                            <?php if ( ! empty( $q['class_level'] ) ) : ?>· <?php echo esc_html( (string) $q['class_level'] ); ?><?php endif; ?>
                            · <?php echo esc_html( (string) (float) $q['marks'] ); ?> mark(s)
                        </span>
                        <?php if ( $objective && (int) $q['correct_count'] === 0 ) : ?>
                            <span class="educbt-pill educbt-pill--draft">no correct answer</span>
                        <?php endif; ?>
                        <button type="button" class="educbt-btn"
                                onclick="document.getElementById('qe-<?php echo esc_attr( (string) $qid ); ?>').toggleAttribute('hidden')">Edit</button>
                        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline"
                              onsubmit="return confirm('Duplicate this question as a new draft?');">
                            <input type="hidden" name="action" value="educbt_duplicate_question">
                            <input type="hidden" name="question_id" value="<?php echo esc_attr( (string) $qid ); ?>">
                            <?php wp_nonce_field( 'educbt_duplicate_question' ); ?>
                            <button type="submit" class="educbt-btn" style="color:var(--edu-accent);border-color:var(--edu-accent-soft)">Duplicate</button>
                        </form>
                    </div>

                    <div class="q-item__body"><?php echo wp_kses_post( wpautop( (string) $q['question_text'] ) ); ?></div>

                    <?php if ( ! empty( $q['options'] ) ) : ?>
                        <ul class="q-item__options">
                        <?php foreach ( $q['options'] as $opt ) : ?>
                            <li class="<?php echo ! empty( $opt['is_correct'] ) ? 'is-correct' : ''; ?>">
                                <?php echo esc_html( $opt['option_key'] . '. ' . $opt['option_text'] ); ?><?php echo ! empty( $opt['is_correct'] ) ? ' ✓' : ''; ?>
                            </li>
                        <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>

                    <?php if ( ! empty( $q['review_note'] ) ) : ?>
                        <p class="educbt-note educbt-note--warn" style="margin-top:8px"><strong>Reviewer:</strong> <?php echo esc_html( (string) $q['review_note'] ); ?></p>
                    <?php endif; ?>

                    <div id="qe-<?php echo esc_attr( (string) $qid ); ?>" hidden class="q-item__edit">
                        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="educbt-form">
                            <input type="hidden" name="action" value="educbt_update_question">
                            <input type="hidden" name="question_id" value="<?php echo esc_attr( (string) $qid ); ?>">
                            <?php wp_nonce_field( 'educbt_update_question' ); ?>

                            <label>Question</label>
                            <textarea name="question_text" rows="3" required><?php echo esc_textarea( (string) $q['question_text'] ); ?></textarea>

                            <div class="educbt-grid" style="margin-top:10px">
                                <div><label>Marks</label><input name="marks" type="number" step="0.5" min="0.5" value="<?php echo esc_attr( (string) (float) $q['marks'] ); ?>"></div>
                            </div>

                            <?php if ( $objective ) : ?>
                                <p class="educbt-muted" style="margin:12px 0 6px">Tick the correct option.</p>
                                <?php foreach ( $q['options'] as $opt ) : ?>
                                    <div style="display:flex;align-items:center;gap:10px;margin-bottom:7px">
                                        <label style="margin:0;display:flex;align-items:center;gap:6px;min-width:56px">
                                            <input type="radio" name="correct" value="<?php echo esc_attr( (string) $opt['id'] ); ?>"
                                                   style="width:auto" <?php checked( ! empty( $opt['is_correct'] ) ); ?>>
                                            <strong><?php echo esc_html( (string) $opt['option_key'] ); ?></strong>
                                        </label>
                                        <input name="option[<?php echo esc_attr( (string) $opt['id'] ); ?>]" type="text" value="<?php echo esc_attr( (string) $opt['option_text'] ); ?>">
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>

                            <button type="submit" class="educbt-btn educbt-btn--primary" style="margin-top:12px">Save changes</button>
                        </form>

                        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:10px"
                              onsubmit="return confirm('Remove this question?');">
                            <input type="hidden" name="action" value="educbt_delete_question">
                            <input type="hidden" name="question_id" value="<?php echo esc_attr( (string) $qid ); ?>">
                            <?php wp_nonce_field( 'educbt_delete_question' ); ?>
                            <button type="submit" class="educbt-btn" style="color:#b91c1c;border-color:#f3c9c9">Delete</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        </section>
        <?php
    };

    $render_bank( $bank_objective, $is_reviewer ? 'Objective questions submitted' : 'My objective questions', true );
    $render_bank( $bank_theory, $is_reviewer ? 'Written questions submitted' : 'My written questions', false );
};

require EDUCBT_PRO_PATH . 'templates/portal/shell.php';

<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
?>
<main class="site-main site-main--center">
    <h1><?php esc_html_e( 'Page not found', 'educbt-theme' ); ?></h1>
    <p><?php esc_html_e( 'That page does not exist.', 'educbt-theme' ); ?></p>
    <p><a class="site-btn site-btn--primary" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Back to the site', 'educbt-theme' ); ?></a></p>
</main>
<?php get_footer(); ?>

/**
 * Trial Portal JS — mirrors the CBT exam portal interface exactly.
 * Subject selection → name entry → full CBT exam UI → results with review.
 *
 * Copy/paste/right-click/dev-tools are disabled during the test, same as real exams.
 */
(function ($) {
    'use strict';

    if (typeof trialPortal === 'undefined') { return; }

    var cfg = trialPortal;
    var restUrl = cfg.restUrl;
    var i18n = cfg.i18n || {};

    // State
    var state = {
        subjectCode: '',
        subjectName: '',
        displayName: '',
        token: '',
        questions: [],
        currentIndex: 0,
        responses: {},       // { question_id: "option_key" (A, B, C, D) }
        timerSeconds: cfg.durationSeconds || 120,
        timerInterval: null,
        isSubmitting: false,
    };

    // ===== EXAM SECURITY: Disable copy, paste, cut, right-click, dev tools =====
    document.addEventListener('contextmenu', function (e) {
        if (state.token) { e.preventDefault(); return false; }
    });

    ['copy', 'cut', 'paste'].forEach(function (eventName) {
        document.addEventListener(eventName, function (e) {
            if (state.token) { e.preventDefault(); return false; }
        });
    });

    document.addEventListener('selectstart', function (e) {
        if (state.token) {
            if (e.target.closest('#trial-exam-area')) { e.preventDefault(); return false; }
        }
    });

    document.addEventListener('keydown', function (e) {
        if (!state.token) return;
        var key = e.key.toLowerCase();
        var ctrlOrCmd = e.ctrlKey || e.metaKey;

        if (ctrlOrCmd && ['c', 'v', 'a', 's', 'u', 'p', 'x'].includes(key)) {
            e.preventDefault(); return false;
        }
        if (e.key === 'F12' || (ctrlOrCmd && e.shiftKey && ['i', 'j', 'c'].includes(key))) {
            e.preventDefault(); return false;
        }
    });

    document.addEventListener('dragstart', function (e) {
        if (state.token && e.target.closest('#trial-exam-area')) {
            e.preventDefault(); return false;
        }
    });

    // ===== INIT =====
    $(document).ready(function () {
        loadSubjects();
        $('#trial-begin').on('click', startTest);
        $('#trial-back').on('click', backToSubjects);
    });

    function escapeHtml(str) {
        return String(str).replace(/[&<>"']/g, function (m) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m];
        });
    }

    function pad(n) { return (n < 10 ? '0' : '') + n; }

    // ===== SUBJECT SELECTION =====
    function loadSubjects() {
        $.ajax({
            url: restUrl + '/trial/subjects',
            method: 'GET',
            success: function (res) {
                if (res && res.success && res.subjects && res.subjects.length > 0) {
                    renderSubjects(res.subjects);
                } else {
                    $('#trial-subjects-grid').html('<p style="color:var(--ep-text-muted)">' + escapeHtml(i18n.notAvailable || 'Not available') + '</p>');
                }
            },
            error: function () {
                $('#trial-subjects-grid').html('<p style="color:var(--ep-primary)">' + escapeHtml(i18n.loadFailed || 'Failed to load') + '</p>');
            }
        });
    }

    function renderSubjects(subjects) {
        var html = '';
        for (var i = 0; i < subjects.length; i++) {
            var s = subjects[i];
            html += '<button type="button" class="ep-option" style="cursor:pointer;text-align:center;flex-direction:column;gap:6px;align-items:center" '
                + 'data-code="' + escapeHtml(s.subject_code) + '" data-name="' + escapeHtml(s.subject_name) + '">';
            html += '<div style="font-size:18px;font-weight:600;color:var(--ep-text)">' + escapeHtml(s.subject_name) + '</div>';
            html += '<div style="font-size:13px;color:var(--ep-text-dim)">' + escapeHtml(String(s.available)) + ' ' + escapeHtml(i18n.questionsAvailable || 'questions available') + '</div>';
            html += '</button>';
        }
        $('#trial-subjects-grid').html(html);

        $('#trial-subjects-grid .ep-option').on('click', function () {
            state.subjectCode = $(this).data('code');
            state.subjectName = $(this).data('name');
            $('#trial-subjects-grid').attr('hidden', true);
            $('#trial-name-form').removeAttr('hidden');
            $('#trial-full-name').focus();
        });
    }

    function backToSubjects() {
        $('#trial-name-form').attr('hidden', true);
        $('#trial-subjects-grid').removeAttr('hidden');
        $('#trial-full-name').val('');
    }

    // ===== START TEST =====
    function startTest() {
        var name = $('#trial-full-name').val().trim();
        if (!name) {
            $('#trial-full-name').css('border-color', 'var(--ep-primary)').focus();
            return;
        }
        if (!state.subjectCode) return;

        state.displayName = name;
        $('#trial-start-screen').attr('hidden', true);
        $('#trial-loading').removeAttr('hidden');

        $.ajax({
            url: restUrl + '/trial/start',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                subject_code: state.subjectCode,
                display_name: name,
                count: cfg.questionCount || 5,
            }),
            success: function (res) {
                if (res && res.success) {
                    state.token = res.token;
                    state.questions = res.questions || [];
                    state.timerSeconds = res.duration_seconds || cfg.durationSeconds || 120;
                    $('#trial-loading').attr('hidden', true);
                    $('#trial-exam-area').removeAttr('hidden');
                    enterFullscreen();
                    renderExam();
                    startTimer();
                } else {
                    showError(res && res.error ? res.error : (i18n.loadFailed || 'Failed to start'));
                }
            },
            error: function (xhr) {
                var msg = i18n.loadFailed || 'Failed to start';
                if (xhr.responseJSON && xhr.responseJSON.error) {
                    msg = xhr.responseJSON.error;
                }
                showError(msg);
            }
        });
    }

    function showError(msg) {
        $('#trial-loading').attr('hidden', true);
        $('#trial-exam-area').removeAttr('hidden').html(
            '<div class="educbt-exam-loading"><p style="color:var(--ep-primary);font-size:16px">' + escapeHtml(msg) + '</p>'
            + '<button class="ep-nav-btn ep-btn-prev" onclick="location.reload()" style="margin-top:20px">' + escapeHtml(i18n.back || 'Back') + '</button></div>'
        );
    }

    function enterFullscreen() {
        var el = document.getElementById('trial-portal');
        if (el.requestFullscreen) { el.requestFullscreen().catch(function(){}); }
        else if (el.webkitRequestFullscreen) { el.webkitRequestFullscreen(); }
        else if (el.msRequestFullscreen) { el.msRequestFullscreen(); }
    }

    // ===== ENFORCE FULLSCREEN: if the candidate escapes (Esc key, etc.) while the
    // test is in progress, immediately re-request it. Only releases on submit. =====
    function isFullscreenActive() {
        return !!(document.fullscreenElement || document.webkitFullscreenElement || document.msFullscreenElement);
    }

    ['fullscreenchange', 'webkitfullscreenchange', 'msfullscreenchange'].forEach(function (evt) {
        document.addEventListener(evt, function () {
            if (state.token && !state.isSubmitting && !isFullscreenActive()) {
                setTimeout(enterFullscreen, 150);
            }
        });
    });

    function exitFullscreen() {
        if (document.fullscreenElement) {
            if (document.exitFullscreen) { document.exitFullscreen().catch(function(){}); }
            else if (document.webkitExitFullscreen) { document.webkitExitFullscreen(); }
            else if (document.msExitFullscreen) { document.msExitFullscreen(); }
        }
    }

    // ===== RENDER EXAM (mirrors exam-portal.js exactly) =====
    function renderExam() {
        if (state.questions.length === 0) {
            showError('No questions found.');
            return;
        }

        var html = '';

        // Header — identical to exam portal
        html += '<div class="ep-header">';
        html += '  <div class="ep-header-left">';
        html += '    <div>';
        html += '      <div class="ep-exam-title">' + escapeHtml(state.subjectName) + '</div>';
        html += '      <div class="ep-exam-subtitle">' + state.questions.length + ' ' + escapeHtml(i18n.questions || 'Questions') + ' · ' + escapeHtml(state.displayName) + '</div>';
        html += '    </div>';
        html += '  </div>';
        html += '  <div class="ep-timer" id="ep-timer">';
        html += '    <span class="ep-timer-icon">⏱</span>';
        html += '    <span class="ep-timer-display" id="ep-timer-display">00:00</span>';
        html += '  </div>';
        html += '</div>';

        // Main layout
        html += '<div class="ep-main">';

        // Question area
        html += '  <div class="ep-question-area" id="ep-question-area">';
        html += '    <div class="ep-question-container" id="ep-question-container"></div>';
        html += '  </div>';

        // Sidebar — question navigator
        html += '  <div class="ep-sidebar">';

        // Candidate profile card (trial version — uses display name + subject)
        var trialInitials = '';
        if (state.displayName) {
            var parts = state.displayName.trim().split(/\s+/);
            trialInitials = (parts[0] ? parts[0][0] : '') + (parts.length > 1 && parts[parts.length - 1] ? parts[parts.length - 1][0] : '');
        }
        html += '    <div class="ep-candidate">';
        html += '      <div class="ep-candidate-avatar">' + escapeHtml(trialInitials) + '</div>';
        html += '      <div class="ep-candidate-name">' + escapeHtml(state.displayName) + '</div>';
        html += '      <div class="ep-candidate-info">';
        html += '        <div class="ep-candidate-info-row"><span class="ep-candidate-info-label">Subject:</span><span class="ep-candidate-info-value">' + escapeHtml(state.subjectName) + '</span></div>';
        html += '        <div class="ep-candidate-info-row"><span class="ep-candidate-info-label">Mode:</span><span class="ep-candidate-info-value">Trial / Practice</span></div>';
        html += '      </div>';
        html += '    </div>';

        html += '    <div class="ep-sidebar-header">';
        html += '      <div class="ep-sidebar-title">' + escapeHtml(i18n.navigator || 'Question Navigator') + '</div>';
        html += '      <div class="ep-sidebar-stats">';
        html += '        <div class="ep-sidebar-stat"><span class="ep-sidebar-dot answered"></span> ' + escapeHtml(i18n.answered || 'Answered') + '</div>';
        html += '        <div class="ep-sidebar-stat"><span class="ep-sidebar-dot unanswered"></span> ' + escapeHtml(i18n.unanswered || 'Unanswered') + '</div>';
        html += '      </div>';
        html += '    </div>';
        html += '    <div class="ep-question-grid" id="ep-question-grid"></div>';
        html += '  </div>';

        html += '</div>';

        $('#trial-exam-area').html(html);
        renderQuestion();
        renderNavigator();

        // Keyboard shortcuts (same as exam portal)
        $(document).off('keydown.trial').on('keydown.trial', function (e) {
            if (state.isSubmitting) return;
            if (e.key === 'ArrowLeft' && state.currentIndex > 0) { e.preventDefault(); prevQuestion(); }
            if (e.key === 'ArrowRight' && state.currentIndex < state.questions.length - 1) { e.preventDefault(); nextQuestion(); }
            if (['a', 'b', 'c', 'd'].includes(e.key.toLowerCase())) {
                var letter = e.key.toUpperCase();
                var idx = letter.charCodeAt(0) - 65;
                var $opt = $('.ep-option').eq(idx);
                if ($opt.length) { $opt.trigger('click'); }
            }
        });
    }

    function renderQuestion() {
        var q = state.questions[state.currentIndex];
        if (!q) return;

        var qId = q.id;
        var options = q.options || [];
        var selectedAnswer = state.responses[String(qId)] || '';

        var html = '';

        // Question header
        html += '<div class="ep-question-header">';
        html += '  <div class="ep-question-num">' + escapeHtml(i18n.question || 'Question') + ' ' + (state.currentIndex + 1) + ' ' + escapeHtml(i18n.of || 'of') + ' ' + state.questions.length + '</div>';
        html += '  <div class="ep-question-meta">';
        if (q.topic) html += '<span>' + escapeHtml(q.topic) + '</span>';
        html += '  </div>';
        html += '</div>';

        // Question text
        html += '<div class="ep-question-text">' + escapeHtml(q.text || '') + '</div>';

        // Options
        var letters = ['A', 'B', 'C', 'D', 'E', 'F'];
        html += '<div class="ep-options" id="ep-options">';
        for (var i = 0; i < options.length; i++) {
            var opt = options[i];
            var optKey = opt.key || letters[i];
            var optText = opt.text || '';
            var isSelected = (selectedAnswer === optKey);
            html += '<div class="ep-option' + (isSelected ? ' selected' : '') + '" data-key="' + escapeHtml(optKey) + '" data-qid="' + qId + '">';
            html += '  <div class="ep-option-letter">' + (letters[i] || (i + 1)) + '</div>';
            html += '  <div class="ep-option-text">' + escapeHtml(optText) + '</div>';
            html += '</div>';
        }
        html += '</div>';

        // Navigation
        html += '<div class="ep-nav">';
        html += '  <button class="ep-nav-btn ep-btn-prev" id="ep-btn-prev"' + (state.currentIndex === 0 ? ' disabled' : '') + '>';
        html += '    ← ' + escapeHtml(i18n.prev || 'Previous');
        html += '  </button>';

        if (state.currentIndex === state.questions.length - 1) {
            html += '  <button class="ep-nav-btn ep-btn-submit" id="ep-btn-submit">' + escapeHtml(i18n.submitExam || 'Submit Test') + '</button>';
        } else {
            html += '  <button class="ep-nav-btn ep-btn-next" id="ep-btn-next">';
            html += '    ' + escapeHtml(i18n.next || 'Next') + ' →';
            html += '  </button>';
        }
        html += '</div>';

        $('#ep-question-container').html(html);
        renderNavigator();

        // Bind events
        $('.ep-option').off('click').on('click', function () {
            var qid = $(this).data('qid');
            var key = $(this).data('key');
            selectAnswer(qid, key, $(this));
        });

        $('#ep-btn-prev').off('click').on('click', prevQuestion);
        $('#ep-btn-next').off('click').on('click', nextQuestion);
        $('#ep-btn-submit').off('click').on('click', function () { submitTest(false); });
    }

    function selectAnswer(qId, key, $el) {
        state.responses[String(qId)] = key;
        $el.siblings('.ep-option').removeClass('selected');
        $el.addClass('selected');
        renderNavigator();
    }

    function renderNavigator() {
        var html = '';
        for (var i = 0; i < state.questions.length; i++) {
            var q = state.questions[i];
            var answered = state.responses[String(q.id)] && state.responses[String(q.id)] !== '';
            var isCurrent = (i === state.currentIndex);
            var classes = 'ep-q-btn';
            if (answered) classes += ' answered';
            if (isCurrent) classes += ' current';
            html += '<button class="' + classes + '" data-index="' + i + '">' + (i + 1) + '</button>';
        }
        $('#ep-question-grid').html(html);
        $('#ep-question-grid .ep-q-btn').off('click').on('click', function () {
            state.currentIndex = parseInt($(this).data('index'), 10);
            renderQuestion();
        });
    }

    function prevQuestion() {
        if (state.currentIndex > 0) {
            state.currentIndex--;
            renderQuestion();
        }
    }

    function nextQuestion() {
        if (state.currentIndex < state.questions.length - 1) {
            state.currentIndex++;
            renderQuestion();
        }
    }

    // ===== TIMER =====
    function startTimer() {
        updateTimerDisplay();
        state.timerInterval = setInterval(function () {
            state.timerSeconds--;
            if (state.timerSeconds <= 0) {
                state.timerSeconds = 0;
                clearInterval(state.timerInterval);
                updateTimerDisplay();
                alert(i18n.timeUp || 'Time is up!');
                submitTest(true);
                return;
            }
            updateTimerDisplay();
        }, 1000);
    }

    function updateTimerDisplay() {
        var s = state.timerSeconds;
        var m = Math.floor(s / 60);
        var sec = s % 60;
        var display = pad(m) + ':' + pad(sec);
        $('#ep-timer-display').text(display);

        var $timer = $('#ep-timer');
        $timer.removeClass('warning danger');
        if (s <= 30) { $timer.addClass('danger'); }
        else if (s <= 60) { $timer.addClass('warning'); }
    }

    // ===== SUBMIT =====
    function submitTest(forced) {
        if (state.isSubmitting) return;

        if (!forced) {
            var answered = Object.keys(state.responses).filter(function (k) {
                return state.responses[k] && state.responses[k] !== '';
            }).length;
            var unanswered = state.questions.length - answered;

            var msg = i18n.confirmSubmit || 'Are you sure?';
            if (unanswered > 0) {
                msg += '\n\n' + unanswered + ' unanswered question(s) out of ' + state.questions.length + '.';
            }
            if (!confirm(msg)) { return; }
        }

        state.isSubmitting = true;
        clearInterval(state.timerInterval);

        $.ajax({
            url: restUrl + '/trial/submit',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                token: state.token,
                answers: state.responses,
            }),
            success: function (res) {
                if (res && res.success) {
                    exitFullscreen();
                    renderResults(res);
                } else {
                    showError(res && res.error ? res.error : 'Submission failed');
                    state.isSubmitting = false;
                }
            },
            error: function () {
                showError('Submission failed. Please try again.');
                state.isSubmitting = false;
            }
        });
    }

    function renderResults(data) {
        var score = data.score || 0;
        var total = data.total || state.questions.length;
        var pct = data.percentage || (total > 0 ? Math.round((score / total) * 100) : 0);
        var grade = data.grade || '-';
        var review = data.review || [];
        var initial = state.displayName.charAt(0).toUpperCase() || '?';

        var html = '';
        html += '<div class="ep-results">';

        // Avatar with initial
        html += '<div style="width:64px;height:64px;border-radius:50%;background:var(--ep-accent);color:#fff;display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:700;margin-bottom:16px">' + escapeHtml(initial) + '</div>';

        html += '<div class="ep-results-title">' + escapeHtml(state.displayName) + '</div>';
        html += '<div class="ep-results-subtitle">' + escapeHtml(state.subjectName) + ' — ' + escapeHtml(i18n.examSubmitted || 'Submitted') + '</div>';

        // Score card
        html += '<div class="ep-results-card">';
        html += '  <div class="ep-results-stat"><div class="ep-results-stat-value score">' + score + '/' + total + '</div><div class="ep-results-stat-label">' + escapeHtml(i18n.scoreLabel || 'Score') + '</div></div>';
        html += '  <div class="ep-results-stat"><div class="ep-results-stat-value grade">' + pct + '%</div><div class="ep-results-stat-label">Percentage</div></div>';
        html += '</div>';

        // Review (trial mode shows explanations)
        // The API returns per-question fields as: question, options (A-D map),
        // your_answer (a single option letter or '' if skipped), correct_answer
        // (a single letter), is_correct, was_skipped. Reading the wrong field names
        // here previously made every row show "Not answered" no matter what the
        // candidate actually picked, while the correct/incorrect colour still came
        // from the (correctly computed) is_correct flag — hence right-looking colours
        // next to a permanently wrong label.
        if (review.length > 0) {
            html += '<div class="ep-review" style="max-width:800px;width:100%;text-align:left">';
            for (var i = 0; i < review.length; i++) {
                var r = review[i];
                var opts = r.options || {};
                var yourLetter = r.your_answer || '';
                var correctLetter = r.correct_answer || '';
                var skipped = !!r.was_skipped || yourLetter === '';
                var yourText = skipped ? 'Not answered' : (opts[yourLetter] || yourLetter);
                var correctText = opts[correctLetter] || correctLetter;

                var rowClass = skipped ? 'skipped' : (r.is_correct ? 'correct' : 'incorrect');

                html += '<div class="ep-review-item">';
                html += '  <div class="ep-review-question">' + (i + 1) + '. ' + escapeHtml(r.question || '') + '</div>';
                html += '  <div class="ep-review-answer ' + rowClass + '">';
                html += '    <span class="ep-review-label">Your answer:</span> ' + escapeHtml(yourText);
                html += '  </div>';
                if (!r.is_correct) {
                    html += '  <div class="ep-review-answer correct">';
                    html += '    <span class="ep-review-label">Correct answer:</span> ' + escapeHtml(correctText);
                    html += '  </div>';
                }
                if (r.explanation) {
                    html += '  <div class="ep-review-explanation">' + escapeHtml(r.explanation) + '</div>';
                }
                html += '</div>';
            }
            html += '</div>';
        }

        // Actions
        html += '<div style="display:flex;gap:12px;justify-content:center;margin-top:32px;flex-wrap:wrap">';
        html += '  <button class="ep-nav-btn ep-btn-submit" id="trial-retake-btn">' + escapeHtml(i18n.retake || 'Retake') + '</button>';
        html += '  <button class="ep-nav-btn ep-btn-next" onclick="location.reload()">' + escapeHtml(i18n.switchSubject || 'Switch subject') + '</button>';
        html += '</div>';

        html += '</div>';

        $('#trial-exam-area').attr('hidden', true);
        $('#trial-results-area').removeAttr('hidden').html(html);

        $('#trial-retake-btn').off('click').on('click', retakeTest);
    }

    // ===== RETAKE (same subject, fresh questions — no trip back to subject picker) =====
    function retakeTest() {
        state.token = '';
        state.questions = [];
        state.currentIndex = 0;
        state.responses = {};
        state.isSubmitting = false;

        $('#trial-results-area').attr('hidden', true);
        $('#trial-exam-area').removeAttr('hidden').html(
            '<div class="educbt-exam-loading"><div class="educbt-exam-spinner"></div><p>' + escapeHtml(i18n.startingTest || 'Starting test...') + '</p></div>'
        );

        $.ajax({
            url: restUrl + '/trial/start',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                subject_code: state.subjectCode,
                display_name: state.displayName,
                count: cfg.questionCount || 5,
            }),
            success: function (res) {
                if (res && res.success) {
                    state.token = res.token;
                    state.questions = res.questions || [];
                    state.timerSeconds = res.duration_seconds || cfg.durationSeconds || 120;
                    enterFullscreen();
                    renderExam();
                    startTimer();
                } else {
                    showError(res && res.error ? res.error : (i18n.loadFailed || 'Failed to start'));
                }
            },
            error: function () {
                showError(i18n.loadFailed || 'Failed to start');
            }
        });
    }

})(jQuery);

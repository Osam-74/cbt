<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
?>
<main class="site-main">
    <?php while ( have_posts() ) : the_post(); ?>
        <article <?php post_class( 'site-entry' ); ?>>
            <h1><?php the_title(); ?></h1>
            <div class="site-entry__body"><?php the_content(); ?></div>
        </article>
    <?php endwhile; ?>
</main>
<?php get_footer(); ?>

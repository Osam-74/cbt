<?php
/**
 * Front page.
 *
 * School subdomain: crest + two buttons (portal, practice test). Nothing else.
 * Root domain: same two buttons, no crest.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

$school_id = 0;

if ( educbt_theme_has_plugin() && class_exists( '\EduCBTPro\Core\TenantContext' ) ) {
    $school_id = absint( ( new \EduCBTPro\Core\TenantContext() )->resolve_from_host() ?? 0 );
}

get_header();
?>
<main class="site-main site-main--wide site-main--center">
    <section class="hero">
        <?php
        if ( $school_id > 0 ) :
            $branding = ( new \EduCBTPro\Services\DocumentBrandingService() )->letterhead( $school_id );
            if ( ! empty( $branding['logo'] ) ) :
                ?>
                <img class="hero__crest" src="<?php echo esc_url( $branding['logo'] ); ?>" alt="" style="max-height:72px;margin-bottom:24px">
                <?php
            endif;
        endif;
        ?>

        <div class="hero__actions">
            <?php if ( educbt_theme_has_plugin() ) : ?>
                <a class="site-btn site-btn--primary site-btn--lg" href="<?php echo esc_url( educbt_theme_portal_url() ); ?>">
                    <?php esc_html_e( 'Go to Portal', 'educbt-theme' ); ?>
                </a>
                <a class="site-btn site-btn--lg" href="<?php echo esc_url( home_url( '/trial/' ) ); ?>">
                    <?php esc_html_e( 'Try a Practice Test', 'educbt-theme' ); ?>
                </a>
            <?php endif; ?>
        </div>
    </section>
</main>
<?php
get_footer();

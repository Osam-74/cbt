<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
?>
<main class="site-main">
    <?php if ( have_posts() ) : ?>
        <?php while ( have_posts() ) : the_post(); ?>
            <article <?php post_class( 'site-entry' ); ?>>
                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                <div class="site-entry__body"><?php the_excerpt(); ?></div>
            </article>
        <?php endwhile; ?>
        <?php the_posts_pagination(); ?>
    <?php else : ?>
        <p><?php esc_html_e( 'Nothing here yet.', 'educbt-theme' ); ?></p>
    <?php endif; ?>
</main>
<?php get_footer(); ?>

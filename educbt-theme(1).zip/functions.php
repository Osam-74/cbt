<?php
/**
 * EduCBT companion theme.
 *
 * The v1 theme created its own portal pages, filtered login redirects and gated
 * access in template_redirect. The plugin does all three, so the two fought and the
 * user ended up back at wp-admin.
 *
 * This theme therefore does NONE of that. There is no dashboard template, no login
 * page, no access control and no portal routing here. Anything the portal needs
 * comes from the plugin, which means the portal behaves identically whether this
 * theme is active or not — and a school can swap the theme without breaking it.
 *
 * @package EduCBT
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'EDUCBT_THEME_VERSION', '1.3.0' );

function educbt_theme_setup(): void {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', [ 'search-form', 'gallery', 'caption', 'style', 'script' ] );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'custom-logo', [ 'height' => 80, 'width' => 80, 'flex-height' => true, 'flex-width' => true ] );

    register_nav_menus( [ 'primary' => __( 'Primary Menu', 'educbt-theme' ) ] );
}
add_action( 'after_setup_theme', 'educbt_theme_setup' );

function educbt_theme_assets(): void {
    wp_enqueue_style( 'educbt-theme', get_stylesheet_uri(), [], EDUCBT_THEME_VERSION );

    $site = get_template_directory() . '/assets/site.css';

    if ( file_exists( $site ) ) {
        wp_enqueue_style(
            'educbt-theme-site',
            get_template_directory_uri() . '/assets/site.css',
            [ 'educbt-theme' ],
            (string) filemtime( $site )
        );
    }
}
add_action( 'wp_enqueue_scripts', 'educbt_theme_assets' );

/**
 * Is the plugin present? The theme is usable without it, but the public site
 * should not advertise a portal that does not exist.
 */
function educbt_theme_has_plugin(): bool {
    return defined( 'EDUCBT_PRO_LOADED' );
}

function educbt_theme_portal_url(): string {
    return home_url( '/portal/' );
}

/**
 * The site title for the current host: a school's own name on its subdomain,
 * otherwise the WordPress site name.
 */
function educbt_theme_site_name(): string {
    if ( educbt_theme_has_plugin() && class_exists( '\EduCBTPro\Core\TenantContext' ) ) {
        $school_id = absint( ( new \EduCBTPro\Core\TenantContext() )->resolve_from_host() ?? 0 );

        if ( $school_id > 0 && class_exists( '\EduCBTPro\Services\DocumentBrandingService' ) ) {
            $branding = ( new \EduCBTPro\Services\DocumentBrandingService() )->letterhead( $school_id );

            if ( ! empty( $branding['name'] ) ) {
                return (string) $branding['name'];
            }
        }
    }

    return (string) get_bloginfo( 'name' );
}

/**
 * Admin notice if the plugin is missing, so a blank site has an explanation.
 */
function educbt_theme_plugin_notice(): void {
    if ( educbt_theme_has_plugin() || ! current_user_can( 'activate_plugins' ) ) {
        return;
    }

    echo '<div class="notice notice-warning"><p><strong>EduCBT theme:</strong> the EduCBT Pro plugin is not active, so the portal is unavailable.</p></div>';
}
add_action( 'admin_notices', 'educbt_theme_plugin_notice' );

/**
 * Practice test route: /trial/
 *
 * Uses TWO strategies so /trial/ works regardless of permalink state:
 *
 * 1. Rewrite rule (needs a one-time flush)
 * 2. Path-based fallback on template_redirect (works immediately, no flush needed)
 *    — same approach the plugin's PortalRouter uses.
 */

// Strategy 1: Rewrite rule
function educbt_theme_trial_rewrite(): void {
    add_rewrite_rule( '^trial/?$', 'index.php?educbt_trial=1', 'top' );
}
add_action( 'init', 'educbt_theme_trial_rewrite' );

function educbt_theme_trial_query_var( $vars ) {
    $vars[] = 'educbt_trial';
    return $vars;
}
add_filter( 'query_vars', 'educbt_theme_trial_query_var' );

// Strategy 2: Path-based fallback — intercepts /trial/ from the URL directly
function educbt_theme_trial_path_catch(): void {
    // If the rewrite already handled it, get_query_var will be '1'
    if ( (string) get_query_var( 'educbt_trial' ) === '1' ) {
        return;
    }

    // Don't touch admin, REST, or AJAX requests
    if ( is_admin() || wp_doing_ajax() ) {
        return;
    }

    // Read the request path
    $uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
    $path = (string) wp_parse_url( $uri, PHP_URL_PATH );

    // Respect a WordPress install in a subdirectory
    $home = (string) wp_parse_url( home_url(), PHP_URL_PATH );
    if ( $home !== '' && $home !== '/' && strpos( $path, $home ) === 0 ) {
        $path = substr( $path, strlen( $home ) );
    }

    $segments = array_values( array_filter( explode( '/', trim( $path, '/' ) ) ) );

    // Only catch exactly /trial or /trial/
    if ( ! empty( $segments ) && strtolower( $segments[0] ) === 'trial' && count( $segments ) === 1 ) {
        $trial = get_stylesheet_directory() . '/trial.php';
        if ( file_exists( $trial ) ) {
            // Make WordPress think this is a real page, not a 404
            global $wp_query;
            $wp_query->is_404 = false;
            $wp_query->is_page = true;
            status_header( 200 );

            include $trial;
            exit;
        }
    }
}
add_action( 'template_redirect', 'educbt_theme_trial_path_catch', 1 );

// Strategy 1 handler: if rewrite rule set the query var, use the trial template
function educbt_theme_trial_template( $template ) {
    if ( (string) get_query_var( 'educbt_trial' ) === '1' ) {
        $trial = get_stylesheet_directory() . '/trial.php';
        if ( file_exists( $trial ) ) {
            return $trial;
        }
    }
    return $template;
}
add_filter( 'template_include', 'educbt_theme_trial_template', 5 );

/**
 * Flush rewrite rules on theme activation so the rewrite-based path works too.
 */
function educbt_theme_activate_flush(): void {
    educbt_theme_trial_rewrite();
    flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'educbt_theme_activate_flush' );

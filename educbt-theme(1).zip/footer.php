<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<footer class="site-foot">
    <p>&copy; <?php echo esc_html( (string) gmdate( 'Y' ) ); ?> <?php echo esc_html( educbt_theme_site_name() ); ?></p>
</footer>
<?php wp_footer(); ?>
</body>
</html>

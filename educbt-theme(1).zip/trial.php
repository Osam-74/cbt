<?php
/**
 * Practice test page — no login required.
 *
 * Uses the exact same CBT exam portal interface as real exams so visitors
 * get a true preview of the testing experience.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

// Enqueue the exam portal CSS so the trial looks identical to the real CBT
if ( educbt_theme_has_plugin() && defined( 'EDUCBT_PRO_FILE' ) ) {
    wp_enqueue_style(
        'educbt-exam-portal',
        plugins_url( 'assets/css/exam-portal.css', EDUCBT_PRO_FILE ),
        [],
        '4.0.0'
    );
}

// Localize trial config
$trial_config = [
    'restUrl'    => esc_url_raw( rest_url( 'educbt/v1' ) ),
    'nonce'      => wp_create_nonce( 'wp_rest' ),
    'questionCount' => 5,
    'durationSeconds' => 120, // 2 minutes
    'i18n'       => [
        'chooseSubject'   => __( 'Choose a subject', 'educbt-theme' ),
        'enterName'        => __( 'Enter your full name', 'educbt-theme' ),
        'startTest'        => __( 'Start test', 'educbt-theme' ),
        'back'             => __( 'Back', 'educbt-theme' ),
        'practiceTest'     => __( 'Practice Test', 'educbt-theme' ),
        'practiceLead'     => __( 'Pick a subject and try a short test. No sign-up needed — 5 questions, 2 minutes.', 'educbt-theme' ),
        'questions'         => __( 'Questions', 'educbt-theme' ),
        'question'          => __( 'Question', 'educbt-theme' ),
        'of'                => __( 'of', 'educbt-theme' ),
        'prev'              => __( 'Previous', 'educbt-theme' ),
        'next'              => __( 'Next', 'educbt-theme' ),
        'submitExam'        => __( 'Submit Test', 'educbt-theme' ),
        'answered'          => __( 'Answered', 'educbt-theme' ),
        'unanswered'        => __( 'Unanswered', 'educbt-theme' ),
        'confirmSubmit'     => __( 'Are you sure you want to submit? You cannot change your answers after submission.', 'educbt-theme' ),
        'timeUp'            => __( 'Time is up! Your test is being submitted automatically.', 'educbt-theme' ),
        'examSubmitted'     => __( 'Test submitted successfully!', 'educbt-theme' ),
        'scoreLabel'        => __( 'Score', 'educbt-theme' ),
        'gradeLabel'        => __( 'Grade', 'educbt-theme' ),
        'retake'            => __( 'Retake', 'educbt-theme' ),
        'switchSubject'     => __( 'Switch subject', 'educbt-theme' ),
        'navigator'         => __( 'Question Navigator', 'educbt-theme' ),
        'notAvailable'      => __( 'Practice tests are not available right now.', 'educbt-theme' ),
        'startingTest'      => __( 'Starting test...', 'educbt-theme' ),
        'loadFailed'        => __( 'Failed to load. Please refresh the page.', 'educbt-theme' ),
        'questionsAvailable' => __( 'questions available', 'educbt-theme' ),
    ],
];

wp_enqueue_script(
    'trial-portal',
    get_stylesheet_directory_uri() . '/assets/trial-portal.js',
    [ 'jquery' ],
    '1.1.0',
    true
);
wp_localize_script( 'trial-portal', 'trialPortal', $trial_config );

get_header();
?>
<main class="trial-page-full" id="trial-page">
    <!-- Subject selection + name entry screen -->
    <div id="trial-portal" class="educbt-exam-portal" style="min-height:100vh">
        <!-- Subject selection -->
        <div id="trial-start-screen" style="padding:40px 24px;max-width:700px;margin:0 auto;text-align:center">
            <h1 class="ep-exam-title" style="font-size:28px;margin-bottom:8px"><?php esc_html_e( 'Practice Test', 'educbt-theme' ); ?></h1>
            <p class="ep-exam-subtitle" style="margin-bottom:32px"><?php esc_html_e( 'Pick a subject and try a short test. No sign-up needed — 5 questions, 2 minutes.', 'educbt-theme' ); ?></p>

            <div id="trial-subjects-grid" style="display:grid;grid-template-columns:1fr;gap:14px;max-width:480px;margin:0 auto">
                <div class="educbt-exam-loading"><div class="educbt-exam-spinner"></div><p><?php esc_html_e( 'Loading subjects...', 'educbt-theme' ); ?></p></div>
            </div>

            <div id="trial-name-form" hidden style="max-width:420px;margin:30px auto 0;text-align:center">
                <label for="trial-full-name" style="display:block;font-weight:600;margin-bottom:8px;color:var(--ep-text)"><?php esc_html_e( 'Enter your full name', 'educbt-theme' ); ?></label>
                <input type="text" id="trial-full-name" placeholder="Your full name" maxlength="40" autocomplete="name"
                    style="width:100%;padding:12px 14px;border:1px solid var(--ep-border);border-radius:8px;font-size:16px;margin-bottom:16px;background:var(--ep-surface);color:var(--ep-text)">
                <div style="display:flex;gap:10px;justify-content:center">
                    <button type="button" class="ep-nav-btn ep-btn-submit" id="trial-begin"><?php esc_html_e( 'Start test', 'educbt-theme' ); ?></button>
                    <button type="button" class="ep-nav-btn ep-btn-prev" id="trial-back"><?php esc_html_e( 'Back', 'educbt-theme' ); ?></button>
                </div>
            </div>
        </div>

        <!-- Loading -->
        <div id="trial-loading" class="educbt-exam-loading" hidden>
            <div class="educbt-exam-spinner"></div>
            <p><?php esc_html_e( 'Starting test...', 'educbt-theme' ); ?></p>
        </div>

        <!-- Exam UI rendered by JS here -->
        <div id="trial-exam-area" hidden></div>

        <!-- Results rendered by JS here -->
        <div id="trial-results-area" hidden></div>
    </div>
</main>
<?php get_footer(); ?>

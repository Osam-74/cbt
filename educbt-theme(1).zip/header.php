<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="site-head">
    <div class="site-head__inner">
        <a class="site-head__brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
            <?php if ( has_custom_logo() ) : ?>
                <?php the_custom_logo(); ?>
            <?php endif; ?>
            <span><?php echo esc_html( educbt_theme_site_name() ); ?></span>
        </a>

        <nav class="site-head__nav">
            <?php
            wp_nav_menu(
                [
                    'theme_location' => 'primary',
                    'container'      => false,
                    'fallback_cb'    => false,
                    'depth'          => 1,
                ]
            );
            ?>
            <?php if ( educbt_theme_has_plugin() ) : ?>
                <a class="site-btn site-btn--primary" href="<?php echo esc_url( educbt_theme_portal_url() ); ?>">
                    <?php echo is_user_logged_in() ? esc_html__( 'My Portal', 'educbt-theme' ) : esc_html__( 'Sign in', 'educbt-theme' ); ?>
                </a>
            <?php endif; ?>
        </nav>
    </div>
</header>
